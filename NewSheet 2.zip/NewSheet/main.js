var setupList = [];
var baselineList = [];
var eventList = [];
var ballCounter = 1;
var ballTotal = 0;
var gearTotal = 0;
var radioChecked;
var mode = 0;
var xVal = 0, yVal = 0, imgWidth = 0, imgHeight = 0;

function point_it(event) {
    var img = new Image();
    img.src = document.getElementById("picture");
    imgWidth = document.getElementById("picture").clientWidth;
    imgHeight = document.getElementById("picture").clientHeight;
    xVal = event.offsetX?(event.offsetX):event.pageX-document.getElementById("picture").offsetLeft;
    yVal = event.offsetY?(event.offsetY):event.pageY-document.getElementById("picture").offsetTop;
}

function startGame() {
    setupList = [document.getElementById("fullName").value,
    document.getElementById("matchNum").value,
    document.getElementById("teamNum").value,
    document.getElementById("partner1").value,
    document.getElementById("partner2").value,
    getTime()];
    localStorage.setItem("setupList" + , setupList);
    window.location.replace("mainSheet.html");
}

function gearPlus() {
    gearTotal++;
    document.getElementById("gearDisplay").textContent = gearTotal;
}

function gearMinus() {
    if ((gearTotal - 1) >= 0) {
        gearTotal--;
    }
    document.getElementById("gearDisplay").textContent = gearTotal;
}

$("input[type='radio']").click(function() {
    if (radioChecked == this) {
        this.checked = false;
        radioChecked = null;
    } else {
        radioChecked = this;
    }
});

function defenseToggle() {
    if (document.getElementById("defense").checked) {
        document.getElementById("38").disabled = false;
        document.getElementById("39").disabled = false;
        document.getElementById("40").disabled = false;
        document.getElementById("41").disabled = false;
        document.getElementById("42").disabled = false;
        document.getElementById("43").disabled = false;
        document.getElementById("38").checked = false;
        document.getElementById("39").checked = false;
        document.getElementById("40").checked = false;
        document.getElementById("41").checked = false;
        document.getElementById("42").checked = false;
        document.getElementById("43").checked = false;
    } else {
        document.getElementById("38").disabled = true;
        document.getElementById("39").disabled = true;
        document.getElementById("40").disabled = true;
        document.getElementById("41").disabled = true;
        document.getElementById("42").disabled = true;
        document.getElementById("43").disabled = true;
    }
}

function plusMiss() {
    if (ballTotal < 10) {
        ballCounter = 1;
    } else if (ballTotal < 30) {
        ballCounter = 5;
    } else {
        ballCounter = 10;
    }
    ballTotal += ballCounter;
    document.getElementById("ballDisplay").textContent = ballTotal;
}

function minusMiss() {
    if (ballTotal < 10) {
        ballCounter = 1;
    } else if (ballTotal < 30) {
        ballCounter = 5;
    } else {
        ballCounter = 10;
    }
    ballTotal -= ballCounter;
    if (ballTotal < 0) {
        ballTotal = 0;
    }
    document.getElementById("ballDisplay").textContent = ballTotal;
}

function toggleBaseline() {
    if (document.getElementById("baselineCross").checked) {
        baselineList = [getTime(), "1"];
    } else {
        baselineList = ["","0"];
    }
    localStorage.setItem("baselineList", baselineList);
}

function newEvent() {
    var tempEvent = [];
    var xTap = Math.round((750-yVal)*((750-yVal)/imgHeight));
    var yTap = Math.round(xVal*(1000/imgWidth));
    var fuelScoring = !!$("input[name='fuelScoreStart']:checked").val() || !!$("input[name='lowFuel']:checked").val() || !!$("input[name='fuelScoreEnd']:checked").val();
    
    var gearScore = !!$("input[name='gearScore']:checked").val();
//    alert(($("input[name='gearScore']:checked").val() === undefined) ? "" : $("input[name='gearScore']:checked").val());
    var fuelCollect = !!$("input[name='fuelCollectBefore']:checked").val() || !!$("input[name='fuelCollectAfter']:checked").val();
    
    var gearCollect = false;
    
    var hanging = !!$("input[name='hanging']:checked").val() || !!$("input[name='time']:checked").val();
    
    if (gearTotal != 0 || document.getElementById("gearSuccess").checked) {
        gearCollect = true;
    }
    
    if (fuelScoring) {
        tempEvent = [getTime(), xTap, yTap, mode, 0,$("input[name='fuelScoreStart']:checked").val(),(document.getElementById("hgMiss").checked ? 1 : 0),null,(document.getElementById("lgMiss").checked ? 1 : 0),null,$("input[name='fuelScoreEnd']:checked").val()];
        
        if (document.getElementById("hgMiss").checked) {
            tempEvent[7] = ballTotal;
        }
        if (document.getElementById("lgMiss").checked) {
            tempEvent[9] = $("input[name='lowFuel']:checked").val();
        }
        eventList.push(tempEvent);
    }
    if (fuelCollect) {
        tempEvent = [getTime(), xTap, yTap, mode, 1, $("input[name='fuelCollectBefore']:checked").val(), $("input[name='fuelCollectAfter']:checked").val(),null,null,null,null];
        eventList.push(tempEvent);
    }
    if (gearCollect) {
        tempEvent = [getTime(), xTap, yTap, mode, 2, gearTotal,null,null,null,null];
        if (document.getElementById("gearSuccess").checked) {
            tempEvent[6] = 1;
        } else {
            tempEvent[6] = 0;
        }
        eventList.push(tempEvent);
    }
    if (gearScore) {
        tempEvent = [getTime(), xTap, yTap, mode, 3, $("input[name='gearScore']:checked").val(),null,null,null,null,null];
        eventList.push(tempEvent);
    }
    if (hanging) {
        tempEvent = [getTime(), xTap, yTap, mode, 4, $("input[name='hanging']:checked").val(),$("input[name='time']:checked").val(),null,null,null,null];
        eventList.push(tempEvent);
    }
    localStorage.setItem("eventList", eventList);
    reset();
}

function getTime() { 
    var d = new Date();
    return d.toTimeString().split(' ')[0];
}

function switchToMain() {
    if (document.getElementById("29").checked) {
        mode = 0;
    } else {
        mode = 1;
    }
    $('#mainModal').show();
    $('#hangingModal').hide();
}



function switchToHanging() {
    mode = 2;
    $('#mainModal').hide();
    $('#hangingModal').show();
}

function reset() {
    $("input[type='radio']").removeAttr('checked');
    $("input[type='checkbox']").removeAttr('checked');
// Refresh the jQuery UI buttonset.                  
//    $( "" ).buttonset('refresh');
//    $("input[type='checkbox']").checked = false;
//    localStorage.setItem("setupList", null);
//    localStorage.setItem("baselineList", null);
//    localStorage.setItem("eventList", null);  
    document.getElementById("ballDisplay").textContent = "0";
    document.getElementById("gearDisplay").textContent = "0";
//    setupList = [];
//    baselineList = [];  
//    eventList = [];
    ballCounter = 1;
    ballTotal = 0;
    gearTotal = 0;
    document.getElementById("29").checked = true;
}

var qrCode = new QRCode(document.getElementById("qrcode"), {
            width: 200,
            height: 200
});
function genQr() {
    qrCode.clear();
    var postGame = [$("input[name='fuelFromFloor']:checked").val(),(document.getElementById("defense").checked ? 1 : 0), $("input[name='typeOfDefense']:checked").val(), $("input[name='locOfDefense']:checked").val(), (document.getElementById("driver").checked ? 1 : 0), (document.getElementById("break").checked ? 1 : 0)];
    qrCode.makeCode(localStorage.getItem("setupList")+","+localStorage.getItem("baselineList")+","+localStorage.getItem("eventList") + String(postGame));
}